/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktr-msc-ls1.Entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author Rot2rick
 */
@Embeddable
public class ProfilRoleId implements Serializable {

    @Column(name = "PROFIL", insertable = false, updatable = false)
    private Long profil;

    @Column(name = "ROLE", insertable = false, updatable = false)
    private Long role;

    public ProfilRoleId() {
    }

    public Long getProfil() {
        return profil;
    }

    public void setProfil(Long profil) {
        this.profil = profil;
    }

    public Long getRole() {
        return role;
    }

    public void setRole(Long role) {
        this.role = role;
    }

    @Override
    public String toString() {
        return "ProfilRoleId{" + "profil=" + profil + ", role=" + role + '}';
    }

}
