/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktr-msc-ls1.services.core;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.ejb.Local;

/**
 *
 * @author ARMEL
 * @param <T>
 * @param <PK>
 */
@Local
public interface AppliServiceBeanLocal<T, PK extends java.io.Serializable> {

    T getOne(PK id);

    T find(PK id);
    
    Long getLastId();

    Long count();

    List<T> getAll();

    List<T> getAll(String sortProperty);

    List<T> getAll(String sortProperty, boolean sortAsc);

    List<T> getLastOne();

    List<T> getDescsave();

    List<T> findById();

    List<T> getLastOne(String sortProperty, boolean sortDesc);

    /**
     *
     * @param <E>
     * @param sortProperty
     * @param sortValue
     * @return une liste de T elts trié par sortProperty like sortValue
     */
    <E> List<T> getAll(String sortProperty, E sortValue);

    /**
     *
     * @param <E>
     * @param sortProperty
     * @param sortValue
     * @param sortAsc
     * @return une liste de T elts trié par sortProperty like sortValue
     */
    <E> List<T> getAll(String sortProperty, E sortValue, boolean sortAsc);

    /**
     *
     * @param <E>
     * @param sortProperty
     * @param sortValue
     * @return une liste de T elts trié par sortProperty = sortValue
     */
    <E> List<T> getBy(String sortProperty, E sortValue);

    /**
     *
     * @param <E>
     * @param sortProperty
     * @param sortValue
     * @return une liste de T elts trié par sortProperty = sortValue
     */
    <E> T getOneBy(String sortProperty, E sortValue);

    /**
     *
     * @param <E>
     * @param <F>
     * @param sortProperty premier condition
     * @param andSortProperty seconde condition
     * @param sortValue trié par cette valleur
     * @param andSortValue
     * @return une liste de T elts trié par sortProperty = sortValue et
     * andSortProperty
     */
    <E, F> List<T> getBy(String sortProperty, String andSortProperty, E sortValue, F andSortValue);

    /**
     *
     * @param <E>
     * @param sortProperty
     * @param sortValue
     * @return une liste de T elts trié par sortProperty <> sortValue
     */
    public <E> List<T> getNonBy(String sortProperty, E sortValue);

    List<T> getAll(int first, int count, String sortProperty, boolean sortAsc);

    T saveOne(final T t);

    T updateOne(final T t);

    void deleteOne(PK id);

    void deleteOne(final T t);

    void deleteRange(PK[] pks);

    void deleteRange(Collection<T> ts);

    void deleteRange(Iterator<T> ts);

    Collection<T> saveRange(Collection<T> ts);

    Collection<T> saveRange(Iterator<T> ts);

    Collection<T> updateRange(Collection<T> ts);

    Collection<T> updateRange(Iterator<T> ts);

    void deleteAll();

    boolean exist(final PK pk);

    boolean deleteRealOne(PK id);

    /*Partie 2 TestWork une autre manière 
     *Persist, delete, update, View
     */
    
    /**
     * Permet de selectionner une entite en prenant en parametre son Identifiant
     *
     * @param date1
     * @param date2
     * @return T
     */
    public List<T> selectionnerInterventionPeriode(Date date1, Date date2);

    public List<T> getOrderDesc(String attribut);

    public List<T> getAll(String attribut, String order);

    public T selectionner(PK k);

    T selectionner(String propriete, Object valeur);

    /**
     * Permet de persister une entite
     *
     * @param t
     *
     *
     */
    int compter();

    public List<T> selectionnerParTableAttribut(Object valeur, String attribut);

    public List<T> selectionnerParDeuxAttributs(String att1, String att2, Object val1, Object val2);

    public List<T> selectionnerParCleEtrangere(Object valeur, String attribut);

    List<T> selectionner(String att1, String att2, String att3, Object val1, Object val2);

    List<T> selectionnerTout(String propriete, String mot);

    public void ajouter(T t);

    /**
     * Persister une liste d'une entité
     *
     * @param list
     */
    public void ajouter(List<T> list);

    /**
     * Permet de modifier une entite en prenant en parametre une autre du meme
     * identifiant
     *
     * @param t
     * @return
     */
    public T modifier(final T t);

    /**
     * Permet de modifier une liste d' entite
     *
     * @param list
     */
    public List<T> modifier(List<T> list);

    public void modifierSet(Set<T> list);

    List<T> modifierListe(List<T> list);

    /**
     * Retourne la liste de toutes les entites
     *
     * @return
     */
    public List<T> selectionnerTout();

    /**
     * Supprime logiquement une entite
     *
     * @param t
     * @return
     */
    public void supprimerLogique(T t);

    /**
     * Supprime logiquement une entite
     *
     * @param t
     */
    public void supprimer(T t);

    /**
     * Supprime logiquement une entite à partir de son identifiant
     *
     * @param k
     */
    public void supprimer(PK k);

    public void supprimer(T t, PK k);

    /**
     * Supprime tous les objets d'une classe entite
     */
    public void supprimerTout();

    /*
     * Supprime une liste d'objets d'une classe entité
     * 
     * @param list :: liste d'objets
     */
    public void delete(List<T> list);


    /*
     * Verifier l'existance d'une valeur
     * @param value
     * @param attribut
     */
    public boolean exists(String value, String attribut);

    public boolean existEntite(String attribut1, String attribut2, String valeur1, String valeur2);

    public boolean exists(String attribut1, String attribut2, Object value1, Object value2);

    public String getExecutedSql();

    public String getDatabaseName();

    public String formater(int pos, String value);
    /*Liste parametré" pour les Etats*/
}
