/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktr-msc-ls1.services.core;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import com.ktr-msc-ls1.dao.core.AppliDaoBeanLocal;

/**
 *
 * @author ROT2RICK
 * @param <T>
 * @param <PK>
 */
public abstract class AppliServicesBean<T, PK extends java.io.Serializable> implements AppliServiceBeanLocal<T, PK> {

    protected abstract AppliDaoBeanLocal<T, PK> getDao();

    public AppliServicesBean() {
    }

    @Override
    public synchronized T getOne(PK id) {
        return getDao().getOne(id);
    }

    @Override
    public synchronized T find(PK id) {
        return getDao().find(id);
    }

    @Override
    public synchronized Long count() {
        return this.getDao().count();
    }

    @Override
    public synchronized Long getLastId() {
        return this.getDao().getLastId();
    }

    @Override
    public synchronized List<T> getAll() {
        return this.getDao().getAll();
    }

    @Override
    public synchronized List<T> getAll(String sortProperty) {
        return this.getDao().getAll(sortProperty, true);
    }

    @Override
    public synchronized List<T> getLastOne() {
        return this.getDao().getLastOne();
    }

    @Override
    public synchronized List<T> getDescsave() {
        return this.getDao().getDescsave();
    }

    @Override
    public synchronized List<T> findById() {
        return this.getDao().findById();
    }

    @Override
    public synchronized List<T> getLastOne(String sortProperty, boolean sortDesc) {
        return this.getDao().getLastOne(sortProperty, sortDesc);
    }

    /**
     *
     * @param sortProperty
     * @param sortAsc
     * @return
     */
    @Override
    public synchronized List<T> getAll(String sortProperty, boolean sortAsc) {
        return this.getDao().getAll(sortProperty, sortAsc);
    }

    @Override
    public synchronized <E> List<T> getAll(String sortProperty, E sortValue) {
        return this.getDao().getAll(sortProperty, sortValue);
    }

    @Override
    public synchronized <E> List<T> getAll(String sortProperty, E sortValue, boolean sortAsc) {
        return this.getDao().getAll(sortProperty, sortValue, sortAsc);
    }

    @Override
    public synchronized <E> List<T> getBy(String sortProperty, E sortValue) {
        return this.getDao().getBy(sortProperty, sortValue);
    }

    @Override
    public synchronized <E> T getOneBy(String sortProperty, E sortValue) {
        return this.getDao().getOneBy(sortProperty, sortValue);
    }

    @Override
    public synchronized <E, F> List<T> getBy(String sortProperty, String andSortProperty, E sortValue, F andSortValue) {
        return this.getDao().getBy(sortProperty, sortValue);
    }

    @Override
    public synchronized <E> List<T> getNonBy(String sortProperty, E sortValue) {
        return this.getDao().getNonBy(sortProperty, sortValue);
    }

    @Override
    public synchronized List<T> getAll(int first, int count, String sortProperty, boolean sortAsc) {
        return this.getDao().getAll(first, count, sortProperty, sortAsc);
    }

    @Override
    public synchronized T saveOne(T t) {
        return this.getDao().saveOne(t);
    }

    @Override
    public synchronized T updateOne(T t) {
        return this.getDao().updateOne(t);
    }

    @Override
    public synchronized void deleteOne(PK id) {
        this.getDao().deleteOne(id);
    }

    @Override
    public synchronized void deleteOne(T t) {
        this.getDao().deleteOne(t);
    }

    @Override
    public synchronized void deleteRange(PK[] pks) {
        for (int i = 0; i < pks.length; i++) {
            this.getDao().deleteOne(pks[i]);
        }
    }

    @Override
    public synchronized void deleteRange(Collection<T> ts) {
        this.deleteRange(ts.iterator());
    }

    @Override
    public synchronized void deleteRange(Iterator<T> ts) {
        while (ts.hasNext()) {
            this.getDao().deleteOne(ts.next());
        }
    }

    @Override
    public synchronized Collection<T> saveRange(Collection<T> ts) {
        return this.saveRange(ts.iterator());
    }

    @Override
    public synchronized Collection<T> saveRange(Iterator<T> ts) {
        Collection<T> ts2 = new LinkedList<T>();
        while (ts.hasNext()) {
            ts2.add(this.getDao().saveOne(ts.next()));
        }
        return ts2;
    }

    @Override
    public synchronized Collection<T> updateRange(Collection<T> ts) {
        return this.updateRange(ts.iterator());
    }

    @Override
    public synchronized Collection<T> updateRange(Iterator<T> ts) {
        Collection<T> ts2 = new LinkedList<T>();
        while (ts.hasNext()) {
            ts2.add(this.getDao().updateOne(ts.next()));
        }
        return ts2;
    }

    @Override
    public synchronized void deleteAll() {
        this.getDao().deleteAll();
    }

    @Override
    public boolean exist(PK pk) {
        return this.getDao().getOne(pk) != null;
    }

    @Override
    public boolean deleteRealOne(PK id) {
        return this.getDao().deleteRealOne(id);
    }

    /*Partie 2 TestWork une autre manière 
     *Persist, delete, update, View
     */
    @Override
    public void ajouter(T t) {
        this.getDao().ajouter(t);
    }

    @Override
    public void ajouter(List<T> list) {

        for (T t : list) {
            this.getDao().ajouter(t);
        }
    }

    @Override
    public List<T> selectionnerInterventionPeriode(Date date1, Date date2) {
        return this.getDao().selectionnerInterventionPeriode(date1, date2);
    }

    @Override
    public List<T> modifier(List<T> list) {
        List<T> liste = new ArrayList<T>();
        for (T t : list) {
            this.getDao().modifier(t);
            liste.add(t);
        }
        return liste;
    }

    @Override
    public void modifierSet(Set<T> list) {
        for (T t : list) {
            this.getDao().modifier(t);

        }

    }

    @Override
    public List<T> modifierListe(List<T> list) {
        return this.getDao().modifierListe(list);
    }

    @Override
    public T modifier(T t) {
        return this.getDao().modifier(t);
    }

    @Override
    public List<T> getOrderDesc(String attribut) {
        return this.getDao().getOrderDesc(attribut);
    }

    @Override
    public List<T> selectionnerTout() {
        return this.getDao().selectionnerTout();
    }

    @Override
    public T selectionner(PK k) {
        return this.getDao().selectionner(k);
    }

    @Override
    public List<T> selectionnerParTableAttribut(Object valeur, String attribut) {
        return this.getDao().selectionnerParTableAttribut(valeur, attribut);
    }

    @Override
    public List<T> selectionnerParDeuxAttributs(String att1, String att2, Object val1, Object val2) {
        return this.getDao().selectionnerParDeuxAttributs(att1, att2, val1, val2);
    }

    @Override
    public List<T> selectionner(String att1, String att2, String att3, Object val1, Object val2) {
        return this.getDao().selectionner(att1, att2, att3, val1, val2);
    }

    @Override
    public List<T> getAll(String attribut, String order) {
        return this.getDao().getAll(attribut, order);
    }

    @Override
    public List<T> selectionnerParCleEtrangere(Object valeur, String attribut) {
        return this.getDao().selectionnerParCleEtrangere(valeur, attribut);
    }

    @Override
    public void supprimer(T t) {
        this.getDao().supprimer(t);
    }

    @Override
    public void supprimer(PK k) {
        this.getDao().supprimer(k);
    }

    @Override
    public void supprimerLogique(T t) {
        this.getDao().supprimerLogique(t);
    }

    @Override
    public void supprimerTout() {
        this.getDao().supprimerTout();
    }

    @Override
    public void delete(List<T> list) {
        if (list != null) {
            for (T t : list) {
                this.getDao().supprimer(t);
            }
        }
    }

    @Override
    public void supprimer(T t, PK k) {
        this.getDao().supprimer(t, k);
    }

    @Override
    public boolean exists(String attribut1, String attribut2, Object value1, Object value2) {
        return this.getDao().exists(attribut1, attribut2, value1, value2);
    }

    @Override
    public boolean exists(String value, String attribut) {
        return this.getDao().exists(value, attribut);
    }

    @Override
    public boolean existEntite(String attribut1, String attribut2, String valeur1, String valeur2) {
        return this.getDao().existEntite(attribut1, attribut2, valeur1, valeur2);
    }

    @Override
    public String getExecutedSql() {
        return this.getDao().getExecutedSql();
    }

    @Override
    public List<T> selectionnerTout(String propriete, String mot) {
        return this.getDao().selectionnerTout(propriete, mot);
    }

    @Override
    public int compter() {
        return this.getDao().compter();
    }

    @Override
    public T selectionner(String propriete, Object valeur) {
        return this.getDao().selectionner(propriete, valeur);
    }

    @Override
    public String getDatabaseName() {
        return this.getDao().getDatabaseName();
    }

    @Override
    public String formater(int pos, String value) {

        String val = new String();
        for (int i = 0; i < pos; i++) {
            val = val + "0";
        }
        if (pos > value.length()) {
            val = val.substring(0, pos - value.length()).concat(value);
        } else if (pos == value.length()) {
            val = value;
        }

        return val;
    }

}
