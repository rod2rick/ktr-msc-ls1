/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktr-msc-ls1.services.impl;

import com.ktr-msc-ls1.dao.impl.*;
import com.ktr-msc-ls1.Entities.Profil;
import com.ktr-msc-ls1.dao.core.AppliDaoBean;
import com.ktr-msc-ls1.Entities.ProfilRole;
import com.ktr-msc-ls1.Entities.ProfilRoleId;
import com.ktr-msc-ls1.Entities.Role;
import com.ktr-msc-ls1.dao.ProfilFacadeLocal;
import com.ktr-msc-ls1.dao.ProfilRoleFacadeLocal;
import com.ktr-msc-ls1.services.ProfilRoleServiceLocal;
import com.ktr-msc-ls1.services.core.AppliServicesBean;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import com.ktr-msc-ls1.dao.core.AppliDaoBeanLocal;

/**
 *
 * @author ROT2RICK
 */
@Stateless
public class ProfilRoleService extends AppliServicesBean<ProfilRole, ProfilRoleId> implements ProfilRoleServiceLocal {

    @EJB
    private ProfilRoleFacadeLocal profilRoleFacade;

    @EJB
    private ProfilFacadeLocal profilFacade;

    @Override
    protected AppliDaoBeanLocal<ProfilRole, ProfilRoleId> getDao() {
        return this.profilRoleFacade;
    }

    @Override
    public List<Role> getProfilRoles(Profil profil) {
        return this.profilRoleFacade.getProfilRoles(profil);
    }

    @Override
    public ProfilRole getProfilRoles(Profil profil, Role role) {
        return this.profilRoleFacade.getProfilRoles(profil, role);
    }

    @Override
    public boolean supProfilRoles(ProfilRole cRole) {
        return this.profilRoleFacade.supProfilRoles(cRole);
    }
    
}

   