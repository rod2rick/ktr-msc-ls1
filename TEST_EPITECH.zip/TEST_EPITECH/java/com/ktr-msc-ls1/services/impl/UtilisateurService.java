/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktr-msc-ls1.services.impl;

import com.ktr-msc-ls1.Entities.Utilisateur;
import com.ktr-msc-ls1.dao.UtilisateurFacadeLocal;
import com.ktr-msc-ls1.services.UtilisateurServiceLocal;
import com.ktr-msc-ls1.services.core.AppliServicesBean;
import java.util.Collections;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import com.ktr-msc-ls1.dao.core.AppliDaoBeanLocal;

/**
 *
 * @author ROT2RICK
 */
@Stateless
public class UtilisateurService extends AppliServicesBean<Utilisateur, Long> implements UtilisateurServiceLocal {

    @EJB
    private UtilisateurFacadeLocal utilisateurFacade;

    @Override
    protected AppliDaoBeanLocal<Utilisateur, Long> getDao() {
        return this.utilisateurFacade;
    }

    @Override
    public List<Utilisateur> getUtilisateurs() {
        return this.utilisateurFacade.getUtilisateurs();
    }

    @Override
    public List<Utilisateur> getUtilisateursProfil() {
        return this.utilisateurFacade.getUtilisateursProfil();
    }

    @Override
    public List<Utilisateur> getUtilisateurNonProfil() {
        return this.utilisateurFacade.getUtilisateurNonProfil();
    }
    
    @Override
    public List<Utilisateur> getListUser(Long id) {
        try {
            return this.utilisateurFacade.getListUser(id);
        } catch (Exception e) {
            return Collections.EMPTY_LIST;
        }
    }

}
