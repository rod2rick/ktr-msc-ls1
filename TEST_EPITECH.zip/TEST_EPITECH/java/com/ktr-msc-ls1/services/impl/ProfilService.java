/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktr-msc-ls1.services.impl;


import com.ktr-msc-ls1.dao.core.AppliDaoBeanLocal;
import com.ktr-msc-ls1.dao.ProfilFacadeLocal;
import javax.ejb.EJB;
import com.ktr-msc-ls1.Entities.Profil;
import com.ktr-msc-ls1.services.ProfilServiceLocal;
import com.ktr-msc-ls1.services.core.AppliServicesBean;
import javax.ejb.Stateless;

/**
 *
 * @author ROT2RICK
 */


@Stateless
public class ProfilService extends AppliServicesBean<Profil, Long> implements ProfilServiceLocal {

    @EJB
    private ProfilFacadeLocal profilFacade;

    @Override
    protected AppliDaoBeanLocal<Profil, Long> getDao() {
        return profilFacade;
    }

}
