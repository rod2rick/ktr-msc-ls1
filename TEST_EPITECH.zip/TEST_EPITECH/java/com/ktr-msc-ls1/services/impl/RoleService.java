/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktr-msc-ls1.services.impl;

import com.ktr-msc-ls1.Entities.Role;
import com.ktr-msc-ls1.dao.RoleFacadeLocal;
import com.ktr-msc-ls1.services.RoleServiceLocal;
import com.ktr-msc-ls1.services.core.AppliServicesBean;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import com.ktr-msc-ls1.dao.core.AppliDaoBeanLocal;

/**
 *
 * @author ROT2RICK
 */
@Stateless
public class RoleService extends AppliServicesBean<Role, Long> implements RoleServiceLocal {

    @EJB
    private RoleFacadeLocal roleFacade;

    public RoleService() {
    }

    @Override
    protected AppliDaoBeanLocal<Role, Long> getDao() {
        return this.roleFacade;
    }

    

}
