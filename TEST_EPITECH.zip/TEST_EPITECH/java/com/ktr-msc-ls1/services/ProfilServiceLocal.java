/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktr-msc-ls1.services;

import com.ktr-msc-ls1.Entities.Profil;
import javax.ejb.Local;
import com.ktr-msc-ls1.services.core.AppliServiceBeanLocal;

/**
 *
 * @author ROT2RICK
 */
@Local
public interface ProfilServiceLocal extends AppliServiceBeanLocal<Profil, Long> {

}
