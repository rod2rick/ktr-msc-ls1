/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktr-msc-ls1.services;

import com.ktr-msc-ls1.Entities.Profil;
import com.ktr-msc-ls1.Entities.Role;
import com.ktr-msc-ls1.Entities.ProfilRole;
import com.ktr-msc-ls1.Entities.ProfilRoleId;
import java.util.List;
import javax.ejb.Local;
import com.ktr-msc-ls1.services.core.AppliServiceBeanLocal;

/**
 *
 * @author ROT2RICK
 */
@Local
public interface ProfilRoleServiceLocal extends AppliServiceBeanLocal<ProfilRole, ProfilRoleId> {

    public List<Role> getProfilRoles(Profil profil);

    public ProfilRole getProfilRoles(Profil profil, Role role);

    public boolean supProfilRoles(ProfilRole cRole);

}
