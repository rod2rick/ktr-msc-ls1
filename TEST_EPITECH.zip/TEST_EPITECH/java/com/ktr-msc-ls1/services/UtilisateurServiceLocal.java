/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktr-msc-ls1.services;

import com.ktr-msc-ls1.Entities.Utilisateur;
import java.util.List;
import javax.ejb.Local;
import com.ktr-msc-ls1.services.core.AppliServiceBeanLocal;

/**
 *
 * @author ROT2RICK
 */
@Local
public interface UtilisateurServiceLocal extends AppliServiceBeanLocal<Utilisateur, Long> {

    public List<Utilisateur> getUtilisateurs();

    public List<Utilisateur> getUtilisateursProfil();

    public List<Utilisateur> getUtilisateurNonProfil();

    public List<Utilisateur> getListUser(Long id);
}
