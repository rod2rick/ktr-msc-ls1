/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktr-msc-ls1.web;


import com.ktr-msc-ls1.Entities.Utilisateur;
import com.ktr-msc-ls1.Entities.Profil;
import com.ktr-msc-ls1.services.UtilisateurServiceLocal;
import com.ktr-msc-ls1.utils.constantes.Constante;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.imageio.stream.FileImageOutputStream;
import javax.imageio.stream.ImageOutputStream;
import javax.inject.Named;
import javax.servlet.ServletContext;
import org.apache.shiro.crypto.hash.Sha256Hash;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.event.FlowEvent;

/**
 *
 * @author ROT2RICK
 */
@Named(value = "UtilisateurBean")
@SessionScoped
public class UtilisateurBean implements Serializable {

    @EJB
    private UtilisateurServiceLocal utilisateurService;

    @EJB
    private ProfilServiceLocal profilService;

    private Utilisateur utilisateur;
    private List<Utilisateur> listUtilisateurs, listusers1;
    private boolean skip;

    private Date date = new Date();
    private Profil profil;
    private List<Profil> profils;


    public UtilisateurBean() {
        this.utilisateur = new Utilisateur();
        this.profil = new Profil();
        this.profils = new ArrayList<>();
        this.listUtilisateurs = new ArrayList<>();

    }

    public void cancel(ActionEvent actionEvent) {
        this.utilisateur = new Utilisateur();
    }

    public void save(ActionEvent actionEvent) {
        //UserTransaction tx = TransactionManager.getUserTransaction();
        FacesContext context = FacesContext.getCurrentInstance();
        try {
            
            if (this.utilisateur.getId() == null) {
                this.utilisateur.setLogin((this.utilisateur.getEmail()));
                this.utilisateur.setPassword(new Sha256Hash("epitech").toHex());
                this.utilisateurService.saveOne(utilisateur);
                String log = "login" + " : " + "" + this.utilisateur.getEmail();
                String pass = "mot de passe" + " : " + "epitech";
                context.addMessage(null, new FacesMessage(Constante.ENREGISTREMENT_REUSSI));
            } else {
                this.utilisateurService.updateOne(utilisateur);
                this.utilisateur = new Utilisateur();
                context.addMessage(null, new FacesMessage(Constante.MODIFICATION_REUSSIE));
            }
        } catch (Exception e) {
            e.getMessage();
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Votre enregistrement a échoué", null);
            context.addMessage(null, message);
        }
        this.utilisateur = new Utilisateur();
    }
	
	public String modifier(Long id) throws IOException {
        this.utilisateur = this.utilisateurService.getOne(id);
        FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("idUser", utilisateur.getId());
        this.utilisateur.getDirection();
        this.utilisateur.getNom();
        this.utilisateur.getPrenom();
        this.utilisateur.getPoste();
        this.utilisateur.getEmail();
        this.utilisateur.getTelephone();
        return "/parametrages/editer_technicien.xhtml?faces-redirect=true";
    }


    public void suppression(Long Id) throws IOException {
        FacesContext context = FacesContext.getCurrentInstance();
        this.utilisateur = this.utilisateurService.find(Id);
        if (this.utilisateur.getId() != null) {
            this.utilisateurService.deleteRealOne(Id);
            context.addMessage(null, new FacesMessage(Constante.SUPPRESSION_REUSSIE));
        } else {
            context.addMessage(null, new FacesMessage("Suppression impossible"));
        }
    }

    public Date max() {
        Calendar ca = Calendar.getInstance();
        ca.add(Calendar.YEAR, -15);
        return ca.getTime();
    }

    public void getObject(Long id) {
        this.utilisateur = this.utilisateurService.find(id);
    }

    public String onFlowProcess(FlowEvent event) {
        if (skip) {
            skip = false;   //reset in case user goes back
            return "confirm";
        } else {
            return event.getNewStep();
        }
    }

    public void associerPoste() {
        FacesContext context = FacesContext.getCurrentInstance();
        try {
            listusers1.stream().forEach((_item) -> {
                this.utilisateurService.updateOne(utilisateur);
            });
            context.addMessage(null, new FacesMessage(Constante.PROFIL_POSTE));
        } catch (Exception e) {
            e.getMessage();
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Votre enregistrement a échoué", null);
            context.addMessage(null, message);
        }
    }

    public void associerProfil() {
        FacesContext context = FacesContext.getCurrentInstance();
        try {
            listusers1.stream().map((user1) -> {
                user1.setProfil(this.profil);
                return user1;
            }).forEach((user1) -> {
                this.utilisateurService.updateOne(user1);
            });
            context.addMessage(null, new FacesMessage(Constante.PROFIL_ASSOCIE));
        } catch (Exception e) {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Votre enregistrement a échoué", null);
            context.addMessage(null, message);
        }
    }

    public List<Utilisateur> utilisateursProfil() {
        List<Utilisateur> us = this.utilisateurService.getAll();
        List<Utilisateur> us1 = new ArrayList<>();
        us.stream().filter((us11) -> (us11.getProfil() != null)).forEach((us11) -> {
            us1.add(us11);
        });
        return us1;
    }

    public List<Utilisateur> utilisateursNonProfil() {
        return this.utilisateurService.getUtilisateursProfil();
    }

    public void utilisateursSelectProfil() {
        utilisateursNonProfil().stream().forEach((user1) -> {
            listusers1.add(user1);
        });
    }

    public void activerUtilisateur(Long u) {
        FacesContext context = FacesContext.getCurrentInstance();
        try {
            List<Utilisateur> us = this.utilisateurService.getBy("id", u);
            Utilisateur u2 = new Utilisateur();
            u2 = us.get(0);
            u2.setActif(true);
            this.utilisateurService.updateOne(u2);
            context.addMessage(null, new FacesMessage("Utilisateur activé"));
        } catch (Exception e) {
            e.getMessage();
        }
    }

    public void desactiverUtilisateur(Long u) {
        FacesContext context = FacesContext.getCurrentInstance();
        try {
            List<Utilisateur> us = this.utilisateurService.getBy("id", u);
            Utilisateur u2 = new Utilisateur();
            u2 = us.get(0);
            u2.setActif(false);
            this.utilisateurService.updateOne(u2);
            context.addMessage(null, new FacesMessage("Utilisateur désactivé"));
        } catch (Exception e) {
            e.getMessage();
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "La désactivation a échoué", null);
            context.addMessage(null, message);
        }
    }

    public List<Utilisateur> utilisateurActif() {
        List<Utilisateur> list1 = this.utilisateurService.getUtilisateurNonProfil();
        List<Utilisateur> us = new ArrayList<>();
        list1.stream().filter((u) -> (!list1.contains(u))).forEach((u) -> {
            list1.add(u);
        });
        list1.stream().filter((u) -> (u.isActif() == true)).forEach((u) -> {
            us.add(u);
        });
        return us;
    }

    public List<Utilisateur> utilisateurInactif() {
        List<Utilisateur> list1 = this.utilisateurService.getUtilisateurNonProfil();
        List<Utilisateur> us = new ArrayList<>();
        list1.stream().filter((u) -> (!list1.contains(u))).forEach((u) -> {
            list1.add(u);
        });
        list1.stream().filter((u) -> (u.isActif() == false)).forEach((u) -> {
            us.add(u);
        });
        return us;
    }

    public void modifierutilisateurProfil() {
        FacesContext context = FacesContext.getCurrentInstance();
        try {
            this.utilisateur.setProfil(profil);
            this.utilisateurService.updateOne(utilisateur);
            context.addMessage(null, new FacesMessage(Constante.MODIFICATION_REUSSIE));
        } catch (Exception e) {
            e.getMessage();

            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "La modification du Profil a échoué", null);
            context.addMessage(null, message);
        }
    }

    public boolean checkIntConnection() {
        boolean status = false;
        Socket sock = new Socket();
        InetSocketAddress address = new InetSocketAddress("www.google.com", 80);
        try {
            sock.connect(address, 3000);
            if (sock.isConnected()) {
                status = true;
            }
        } catch (Exception e) {

        } finally {
            try {
                sock.close();
            } catch (Exception e) {
            }
        }
        return status;
    }

    public UtilisateurServiceLocal getUtilisateurService() {
        return utilisateurService;
    }

    public void setUtilisateurService(UtilisateurServiceLocal utilisateurService) {
        this.utilisateurService = utilisateurService;
    }

    public ProfilServiceLocal getProfilService() {
        return profilService;
    }

    public void setProfilService(ProfilServiceLocal profilService) {
        this.profilService = profilService;
    }

    public Utilisateur getUtilisateur() {
        return utilisateur;
    }

    public void setUtilisateur(Utilisateur utilisateur) {
        this.utilisateur = utilisateur;
    }

    public List<Utilisateur> getListusers1() {
        return this.utilisateurService.getUtilisateursProfil();
    }

    public void setListusers1(List<Utilisateur> listusers1) {
        this.listusers1 = listusers1;
    }

    public List<Utilisateur> getListusers() {
        listusers = this.utilisateurService.getAll();
        return listusers;
    }

    public void setListusers(List<Utilisateur> listusers) {
        this.listusers = listusers;
    }

    public List<Profil> getProfils() {
        profils = this.profilService.getAll();
        return profils;
    }

    public void setProfils(List<Profil> profils) {
        this.profils = profils;
    }

    public boolean isSkip() {
        return skip;
    }

    public void setSkip(boolean skip) {
        this.skip = skip;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Profil getProfil() {
        return profil;
    }

    public void setProfil(Profil profil) {
        this.profil = profil;
    }

    public List<Utilisateur> getListUtilisateurs() {
        return this.utilisateurService.getTechniciens("Technicien");
    }

    public void setListUtilisateurs(List<Utilisateur> listUtilisateurs) {
        this.listUtilisateurs = listUtilisateurs;
    }

    public void setListClients(List<Client> listClients) {
        this.listClients = listClients;
    }

}
