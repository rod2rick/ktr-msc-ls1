/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktr-msc-ls1.web;

import com.ktr-msc-ls1.Entities.ProfilRole;
import com.ktr-msc-ls1.services.ProfilRoleServiceLocal;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.faces.view.ViewScoped;

/**
 *
 * @author ROT2RICK
 */
@Named(value = "profilRoleBean")
@ViewScoped
public class ProfilRoleBean implements Serializable {

    @EJB
    private ProfilRoleServiceLocal profilRoleService;

    private ProfilRole profilRole;
    private List<ProfilRole> ProfilRoles;

    public ProfilRoleBean() {
        this.profilRole = new ProfilRole();
    }

    public void save() {
        FacesContext context = FacesContext.getCurrentInstance();
        try {
            if (this.profilRole.getId() == null) {
                this.profilRoleService.saveOne(profilRole);
                System.out.println(profilRole);
            } else {
                this.profilRoleService.updateOne(profilRole);
            }
        } catch (Exception e) {
            e.getMessage();
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Votre enregistrement a échoué", null);
            context.addMessage(null, message);
        }
    }

    public ProfilRoleBean(ProfilRole ProfileRole) {
        this.profilRole = profilRole;
    }

    public ProfilRole getProfilRole() {
        return profilRole;
    }

    public List<ProfilRole> getProfilRoles() {
        return ProfilRoles;
    }

    public void setProfilRole(ProfilRole profilRole) {
        this.profilRole = profilRole;
    }

    public void setProfilRoles(List<ProfilRole> ProfilRoles) {
        this.ProfilRoles = ProfilRoles;
    }

    public ProfilRoleServiceLocal getProfilRoleService() {
        return profilRoleService;
    }

    public void setProfilRoleService(ProfilRoleServiceLocal profilRoleService) {
        this.profilRoleService = profilRoleService;
    }

}
