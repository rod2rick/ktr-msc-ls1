/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktr-msc-ls1.web;

import com.ktr-msc-ls1.Entities.Profil;
import com.ktr-msc-ls1.services.ProfilServiceLocal;
import com.ktr-msc-ls1.utils.constantes.Constante;
import java.awt.event.ActionEvent;
import javax.inject.Named;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;

/**
 *
 * @author ROT2RICK
 */
@Named(value = "profilBean")
@ViewScoped
public class ProfilBean implements Serializable {

    @EJB
    private ProfilServiceLocal profilService;

    private Profil profil;
    private List<Profil> profils;

    public ProfilBean() {
        this.profils = new ArrayList<>();
        this.profil = new Profil();
    }

    public void cancel(ActionEvent actionEvent) {
        this.profil = new Profil();
    }

    public void save(ActionEvent actionEvent) {
        FacesContext context = FacesContext.getCurrentInstance();
        try {
            if (this.profil.getId() == null) {
                this.profilService.saveOne(profil);
                context.addMessage(null, new FacesMessage(Constante.ENREGISTREMENT_REUSSI));
            } else {
                this.profilService.updateOne(profil);
                context.addMessage(null, new FacesMessage(Constante.MODIFICATION_REUSSIE));
            }
        } catch (Exception e) {
            e.getMessage();
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Votre enregistrement a échoué", null);
            context.addMessage(null, message);
        }

    }

    public void getObject(Long id) {
        this.profil = this.profilService.find(id);
    }

    public Profil getProfil() {
        return profil;
    }

    public void setProfil(Profil profil) {
        this.profil = profil;
    }

    public List<Profil> getProfils() {
        profils = this.profilService.getAll();
        return profils;
    }

    public void setProfils(List<Profil> profils) {
        this.profils = profils;
    }

    public ProfilServiceLocal getProfilService() {
        return profilService;
    }

    public void setProfilService(ProfilServiceLocal profilService) {
        this.profilService = profilService;
    }

}
