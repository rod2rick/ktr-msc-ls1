/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktr-msc-ls1.web;

import com.ktr-msc-ls1.Entities.Profil;
import com.ktr-msc-ls1.Entities.ProfilRole;
import com.ktr-msc-ls1.Entities.Role;
import com.ktr-msc-ls1.services.ProfilRoleServiceLocal;
import com.ktr-msc-ls1.services.ProfilServiceLocal;
import com.ktr-msc-ls1.services.RoleServiceLocal;
import com.ktr-msc-ls1.shiro.EntityRealm;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.faces.view.ViewScoped;

/**
 *
 * @author ROT2RICK
 */
@Named(value = "roleBean")
@ViewScoped
public class RoleBean implements Serializable {

    @EJB
    private ProfilServiceLocal profilService;

    @EJB
    private RoleServiceLocal roleService;

    @EJB
    private ProfilRoleServiceLocal profilRoleService;

    private Role role;
    private List<Role> roles;
    private List<Role> selectRoles, selectRolesDol, selectRolesFE, selectRolesRT, selectRolesAut, selectRolesSec;
    private List<Role> ajoutRoles;
    private List<Role> retraitRoles;
    private List<Profil> profils;
    private Profil selectProfil;
    private List<Role> mesRoles;
    private String profil;

    public RoleBean() {
        this.role = new Role();
        ajoutRoles = new ArrayList<>();
        retraitRoles = new ArrayList<>();
        roles = new ArrayList<>();
        selectRoles = new ArrayList<>();
        selectRolesDol = new ArrayList<>();
        selectRolesFE = new ArrayList<>();
        selectRolesRT = new ArrayList<>();
        selectRolesAut = new ArrayList<>();
        selectRolesSec = new ArrayList<>();
        selectProfil = new Profil();
        profils = new ArrayList<>();
        mesRoles = new ArrayList<>();
    }

    @PostConstruct
    private void init() {
        if (EntityRealm.getUser() != null) {
            profil = EntityRealm.getUser().getProfil().getNom();
            List<ProfilRole> l = this.profilRoleService.getBy("profil", EntityRealm.getUser().getProfil());
            for (ProfilRole p : l) {
                mesRoles.add(p.getRole());
            }
        }
    }

    public void setProfilRole() {
        selectRoles = this.profilRoleService.getProfilRoles(selectProfil);
        selectRolesDol = this.profilRoleService.getProfilRoles(selectProfil);
        selectRolesFE = this.profilRoleService.getProfilRoles(selectProfil);
        selectRolesRT = this.profilRoleService.getProfilRoles(selectProfil);
        selectRolesAut = this.profilRoleService.getProfilRoles(selectProfil);
        selectRolesSec = this.profilRoleService.getProfilRoles(selectProfil);
    }

    public void checkAll() {
        for (Object b : this.getSelectRoles()) {
            b = true;
        }
    }

    public void modifierRole() {
        if (selectRoles != null) {
            //recherche des role des profil des personnels
            List<Role> profilRoles = profilRoleService.getProfilRoles(selectProfil);
            //si la liste des roles est vide il s'agit d'une insertion
            if (profilRoles.isEmpty() && !selectRoles.isEmpty()) {
                this.ajoutRolesUsers(selectRoles);
                FacesContext.getCurrentInstance().
                        addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Rôle(s) attribuée(s) avec succès !!!", ""));
                return;
            }
            //si la liste des personne n'est pas vide et ls roles selectioné ne le sont pas on fait une suppression
            if (!profilRoles.isEmpty() && selectRoles.isEmpty()) {
                List<ProfilRole> profilRole = profilRoleService.getBy("profil", selectProfil);
                profilRole.stream().forEach((role2) -> {
                    profilRoleService.supProfilRoles(role2);
                });
                FacesContext.getCurrentInstance().
                        addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Modification effectuée avec succès !!!!", ""));
                return;
            }
            //si la liste des role n'est pas vide et la liste des roles selectionné nest pas vide
            if (!profilRoles.isEmpty() && !selectRoles.isEmpty()) {
                //chercher les role que le personnel a retirer
                profilRoles.stream().filter((roleProfil) -> (!selectRoles.contains(roleProfil))).forEach((roleProfil) -> {
                    retraitRoles.add(roleProfil);
                });
                //chercher les role a ajouter
                selectRoles.stream().filter((roleSelect) -> (!profilRoles.contains(roleSelect))).forEach((roleSelect) -> {
                    ajoutRoles.add(roleSelect);
                });
                //ajout des roles
                if (!ajoutRoles.isEmpty()) {
                    ajoutRolesUsers(ajoutRoles);
                }
                //retrait de role
                if (!retraitRoles.isEmpty()) {
                    retraitRoles.stream().forEach((catPersonneRole) -> {
                        System.out.println(catPersonneRole);
                    });
                    retraitRoles.stream().map((role1) -> profilRoleService.getProfilRoles(selectProfil, role1)).map((profilRol) -> {
                        System.out.println(profilRol);
                        return profilRol;
                    }).filter((profilRol) -> (profilRol != null)).forEach((profilRol) -> {
                        profilRoleService.supProfilRoles(profilRol);
                    });
                }
                FacesContext.getCurrentInstance().
                        addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Info Modification réussie !!!!!!!!", ""));
            }
        }
    }

    public void ajoutRolesUsers(List<Role> roles) {
        roles.stream().map((role1) -> new ProfilRole(selectProfil, role1)).forEach((profilRole) -> {
            profilRoleService.saveOne(profilRole);
        });
    }

    public void saveRole() {
        this.roleService.saveOne(role);
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public List<Role> getRoles() {
        return this.roleService.getAll();
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }

    public List<Role> getSelectRoles() {
        return selectRoles;
    }

    public void setSelectRoles(List<Role> selectRoles) {
        this.selectRoles = selectRoles;
    }

    public List<Role> getAjoutRoles() {
        return ajoutRoles;
    }

    public void setAjoutRoles(List<Role> ajoutRoles) {
        this.ajoutRoles = ajoutRoles;
    }

    public List<Role> getRetraitRoles() {
        return retraitRoles;
    }

    public void setRetraitRoles(List<Role> retraitRoles) {
        this.retraitRoles = retraitRoles;
    }

    public List<Profil> getProfils() {
        return this.profilService.getAll();
    }

    public void setProfils(List<Profil> profils) {
        this.profils = profils;
    }

    public Profil getSelectProfil() {
        return selectProfil;
    }

    public void setSelectProfil(Profil selectProfil) {
        this.selectProfil = selectProfil;
    }

    public ProfilServiceLocal getProfilService() {
        return profilService;
    }

    public void setProfilService(ProfilServiceLocal profilService) {
        this.profilService = profilService;
    }

    public RoleServiceLocal getRoleService() {
        return roleService;
    }

    public void setRoleService(RoleServiceLocal roleService) {
        this.roleService = roleService;
    }

    public ProfilRoleServiceLocal getProfilRoleService() {
        return profilRoleService;
    }

    public void setProfilRoleService(ProfilRoleServiceLocal profilRoleService) {
        this.profilRoleService = profilRoleService;
    }

    public List<Role> getMesRoles() {
        return mesRoles;
    }

    public void setMesRoles(List<Role> mesRoles) {
        this.mesRoles = mesRoles;
    }

    public String getProfil() {
        return profil;
    }

    public void setProfil(String profil) {
        this.profil = profil;
    }

    public List<Role> getSelectRolesDol() {
        return this.roleService.getRolesDol();
    }

    public void setSelectRolesDol(List<Role> selectRolesDol) {
        this.selectRolesDol = selectRolesDol;
    }

    public List<Role> getSelectRolesFE() {
        return this.roleService.getRolesFE();
    }

    public void setSelectRolesFE(List<Role> selectRolesFE) {
        this.selectRolesFE = selectRolesFE;
    }

    public List<Role> getSelectRolesRT() {
        return this.roleService.getRolesRT();
    }

    public void setSelectRolesRT(List<Role> selectRolesRT) {
        this.selectRolesRT = selectRolesRT;
    }

    public List<Role> getSelectRolesAut() {
        return this.roleService.getRolesAut();
    }

    public void setSelectRolesAut(List<Role> selectRolesAut) {
        this.selectRolesAut = selectRolesAut;
    }

    public List<Role> getSelectRolesSec() {
        return this.roleService.getRolesSec();
    }

    public void setSelectRolesSec(List<Role> selectRolesSec) {
        this.selectRolesSec = selectRolesSec;
    }

}
