package com.cagecfi.ultima.view;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class ThemeView implements Serializable {

    private String color;
    private String layoutCss;// = "css/layout-indigo.css";
    private String themeColor;// = "#3F51B5";
    private String theme;

    private String profileLocation; // = "inline";
    private Map<String, String> layoutMap;
    private Map<String, String> themeColorMap;
    private Map<String, String> menuModeClassMap;

    @PostConstruct
    public void init() {
        layoutMap = new HashMap<>();
        layoutMap.put("complaint", "ultima-layout/css/layout-mine.css");
        layoutMap.put("ultima-blue", "ultima-layout/css/layout-blue.css");
        layoutMap.put("ultima-blue-grey", "ultima-layout/css/layout-blue-grey.css");
        layoutMap.put("ultima-brown", "ultima-layout/css/layout-brown.css");
        layoutMap.put("ultima-cyan", "ultima-layout/css/layout-cyan.css");
        layoutMap.put("ultima-dark-blue", "ultima-layout/css/layout-dark-blue.css");
        layoutMap.put("ultima-dark-green", "ultima-layout/css/layout-dark-green.css");
        layoutMap.put("ultima-green", "ultima-layout/css/layout-green.css");
        layoutMap.put("ultima-grey", "ultima-layout/css/layout-grey.css");
        layoutMap.put("ultima-indigo", "ultima-layout/css/layout-indigo.css");
        layoutMap.put("ultima-purple-amber", "ultima-layout/css/layout-purple-amber.css");
        layoutMap.put("ultima-purple-cyan", "ultima-layout/css/layout-purple-cyan.css");
        layoutMap.put("ultima-teal", "ultima-layout/css/layout-teal.css");

        themeColorMap = new HashMap<>();
        themeColorMap.put("ultima-blue", "#03A9F4");
        themeColorMap.put("ultima-blue-grey", "#607D8B");
        themeColorMap.put("ultima-brown", "#795548");
        themeColorMap.put("ultima-cyan", "#00bcd4");
        themeColorMap.put("ultima-dark-blue", "");
        themeColorMap.put("ultima-dark-green", "");
        themeColorMap.put("ultima-green", "#4CAF50");
        themeColorMap.put("ultima-grey", "");
        themeColorMap.put("ultima-indigo", "#3F51B5");
        themeColorMap.put("ultima-purple-amber", "#673AB7");
        themeColorMap.put("ultima-purple-cyan", "#673AB7");
        themeColorMap.put("ultima-teal", "#009688");
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void change(String color) {
        if (color.equals("green")) {
            this.color = null;
        } else {
            this.color = "-" + color;
        }
    }

    public String getTheme() {
        return theme;
    }

    public void setTheme(String theme) {
        this.theme = theme;
        layoutCss = layoutMap.get(theme);
        themeColor = themeColorMap.get(theme);
        if (layoutCss == null) {
            layoutCss = "ultima-layout/css/layout-mine.css";
        }
    }

    public void setTheme1(String theme) {
        this.theme = theme;
        layoutCss = layoutMap.get(theme);
        themeColor = themeColorMap.get(theme);
        if (layoutCss == null) {
            layoutCss = "ultima-layout/css/layout-indigo.css";
        }
    }

    public void setTheme2(String theme) {
        this.theme = theme;
        layoutCss = layoutMap.get(theme);
        themeColor = themeColorMap.get(theme);
        if (layoutCss == null) {
            layoutCss = "ultima-layout/css/layout-brown.css";
        }
    }

    public void setTheme3(String theme) {
        this.theme = theme;
        layoutCss = layoutMap.get(theme);
        themeColor = themeColorMap.get(theme);
        if (layoutCss == null) {
            layoutCss = "ultima-layout/css/layout-blue.css";
        }
    }

    public void setTheme4(String theme) {
        this.theme = theme;
        layoutCss = layoutMap.get(theme);
        themeColor = themeColorMap.get(theme);
        if (layoutCss == null) {
            layoutCss = "ultima-layout/css/layout-blue-grey.css";
        }
    }

    public void setTheme5(String theme) {
        this.theme = theme;
        layoutCss = layoutMap.get(theme);
        themeColor = themeColorMap.get(theme);
        if (layoutCss == null) {
            layoutCss = "ultima-layout/css/layout-dark-blue.css";
        }
    }

    public void setTheme6(String theme) {
        this.theme = theme;
        layoutCss = layoutMap.get(theme);
        themeColor = themeColorMap.get(theme);
        if (layoutCss == null) {
            layoutCss = "ultima-layout/css/layout-dark-green.css";
        }
    }

    public void setTheme7(String theme) {
        this.theme = theme;
        layoutCss = layoutMap.get(theme);
        themeColor = themeColorMap.get(theme);
        if (layoutCss == null) {
            layoutCss = "ultima-layout/css/layout-green.css";
        }
    }

    public void setTheme8(String theme) {
        this.theme = theme;
        layoutCss = layoutMap.get(theme);
        themeColor = themeColorMap.get(theme);
        if (layoutCss == null) {
            layoutCss = "ultima-layout/css/layout-purple-cyan.css";
        }
    }

    public void setTheme9(String theme) {
        this.theme = theme;
        layoutCss = layoutMap.get(theme);
        themeColor = themeColorMap.get(theme);
        if (layoutCss == null) {
            layoutCss = "ultima-layout/css/layout-purple-amber.css";
        }
    }

    public void setTheme10(String theme) {
        this.theme = theme;
        layoutCss = layoutMap.get(theme);
        themeColor = themeColorMap.get(theme);
        if (layoutCss == null) {
            layoutCss = "ultima-layout/css/layout-teal.css";
        }
    }

    public void setTheme11(String theme) {
        this.theme = theme;
        layoutCss = layoutMap.get(theme);
        themeColor = themeColorMap.get(theme);
        if (layoutCss == null) {
            layoutCss = "ultima-layout/css/layout-cyan.css";
        }
    }

    public void setTheme12(String theme) {
        this.theme = theme;
        layoutCss = layoutMap.get(theme);
        themeColor = themeColorMap.get(theme);
        if (layoutCss == null) {
            layoutCss = "ultima-layout/css/layout-grey.css";
        }
    }

}
