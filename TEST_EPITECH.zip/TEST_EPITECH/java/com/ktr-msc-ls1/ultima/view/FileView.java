/*
 * Copyright 2009-2014 PrimeTek.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.cagecfi.ultima.view;

import java.io.InputStream;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

@ManagedBean
public class FileView {

    private StreamedContent file, file1, file2, file3;

    public FileView() {
        InputStream streamdoc = FacesContext.getCurrentInstance().getExternalContext().getResourceAsStream("/resources/docs/GUIDE_UTILISATEUR.pdf");
        file = new DefaultStreamedContent(streamdoc, "docs/pdf", "GUIDE_UTILISATEUR.pdf");
        InputStream streamdoc1 = FacesContext.getCurrentInstance().getExternalContext().getResourceAsStream("/resources/docs/Config_Glassfish+Mysql.zip");
        file1 = new DefaultStreamedContent(streamdoc1, "docs/zip", "Config_Glassfish+Mysql.zip");
        InputStream streamdoc2 = FacesContext.getCurrentInstance().getExternalContext().getResourceAsStream("/resources/docs/Deploiement_War_Glassfish.zip");
        file2 = new DefaultStreamedContent(streamdoc2, "docs/zip", "Deploiement_War_Glassfish.zip");
        InputStream streamdoc3 = FacesContext.getCurrentInstance().getExternalContext().getResourceAsStream("/resources/docs/Utilisation_WampServer.zip");
        file3 = new DefaultStreamedContent(streamdoc3, "docs/zip", "Utilisation_WampServer.zip");
    }

    public StreamedContent getFile() {
        return file;
    }

    public StreamedContent getFile1() {
        return file1;
    }

    public StreamedContent getFile2() {
        return file2;
    }
    
    public StreamedContent getFile3() {
        return file3;
    }

}
