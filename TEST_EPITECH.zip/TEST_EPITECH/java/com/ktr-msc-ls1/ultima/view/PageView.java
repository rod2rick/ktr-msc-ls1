package com.cagecfi.ultima.view;

import com.cagecfi.Entities.Action;
import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class PageView implements Serializable {

    private Action formObject, selectObject, actionPage;

    public String pageIndex() {
        this.actionPage = new Action();
        return "/index.xhtml?faces-redirect=true";
    }

}
