/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktr-msc-ls1.dao.dao.impl;

import com.ktr-msc-ls1.dao.Entities.Utilisateur;
import com.ktr-msc-ls1.dao.dao.core.APPLIDaoBean;
import com.ktr-msc-ls1.dao.dao.UtilisateurFacadeLocal;
import java.util.List;
import javax.ejb.Stateless;

/**
 *
 * @author ROT2RICK
 */
@Stateless
public class UtilisateurFacade extends AppliDaoBean<Utilisateur, Long> implements UtilisateurFacadeLocal {

    public UtilisateurFacade() {
        super(Utilisateur.class);
    }

    @Override
    public Class<Utilisateur> getType() {
        return Utilisateur.class;

    }

    @Override
    public List<Utilisateur> getUtilisateurs() {
        return getEntityManager()
                .createQuery("SELECT u FROM Utilisateur u WHERE u.actif=:actif AND u NOT IN (SELECT ua FROM Utilisateur ua)")
                .setParameter("actif", true)
                .getResultList();
    }

    @Override
    public List<Utilisateur> getUtilisateursProfil() {
        return getEntityManager()
                .createQuery("SELECT u FROM Utilisateur u WHERE u.profil IS NULL")
                .getResultList();
    }

    @Override
    public List<Utilisateur> getUtilisateurNonProfil() {
        return getEntityManager()
                .createQuery("SELECT u FROM Utilisateur u WHERE u.profil IS NOT NULL")
                .getResultList();
				
    @Override
    public List<Utilisateur> getListUser(Long id) {
        return getEntityManager()
                .createQuery("SELECT u FROM Utilisateur u WHERE u.direction.id = :param")
                .setParameter("param", id)
                .getResultList();
    }
}
