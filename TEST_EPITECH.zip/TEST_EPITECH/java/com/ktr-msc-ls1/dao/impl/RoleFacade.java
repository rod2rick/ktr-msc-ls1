/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cagecfi.dao.impl;

import com.cagecfi.Entities.Role;
import com.cagecfi.dao.RoleFacadeLocal;
import com.cagecfi.dao.core.AppliDaoBean;
import java.util.List;
import javax.ejb.Stateless;

/**
 *
 * @author ROT2RICK
 */
@Stateless
public class RoleFacade extends AppliDaoBean<Role, Long> implements RoleFacadeLocal {

    public RoleFacade() {
    }  

}
