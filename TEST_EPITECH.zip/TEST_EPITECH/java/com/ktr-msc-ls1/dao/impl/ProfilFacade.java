/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cagecfi.dao.impl;

;
import com.cagecfi.dao.core.AppliDaoBean;
import com.cagecfi.Entities.Profil;
import com.cagecfi.dao.ProfilFacadeLocal;
import javax.ejb.Stateless;

/**
 *
 * @author ROT2RICK
 */


@Stateless
public class ProfilFacade extends AppliDaoBean<Profil, Long> implements ProfilFacadeLocal {

    public ProfilFacade() {
    }

    @Override
    public Class<Profil> getType() {
        return Profil.class;
    }

}
