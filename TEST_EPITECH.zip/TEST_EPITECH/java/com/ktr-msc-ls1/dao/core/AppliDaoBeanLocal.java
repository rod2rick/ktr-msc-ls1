/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktr-msc-ls1.dao.core;

import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.ejb.Local;
import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 *
 * @author ROT2RICK
 * @param <T> type de sort value
 * @param <PK> type de sort value
 */
@Local
public interface AppliDaoBeanLocal<T, PK extends java.io.Serializable> {

    T getOne(final PK id);

    Long count();
    
    Long getLastId();

    List<T> getAll();

    List<T> getLastOne();

    List<T> getDescsave();

    List<T> getLastsave(Long idFiche);

    List<T> findById();

    List<T> getAll(String sortProperty, boolean sortAsc);

    List<T> getLastOne(String sortProperty, boolean sortDesc);

    /**
     *
     * @param <E> type de sort value
     * @param sortProperty type de sort value
     * @param sortValue type de sort value
     * @retourne une liste de T éléments triés par sortProperty comme sortValue
     */
    <E> List<T> getAll(String sortProperty, E sortValue);

    /**
     *
     * @param <E> type de sort value
     * @param sortProperty type de sort value
     * @param sortValue type de sort value
     * @return une liste de T éléments triés par sortProperty = sortValue
     */
    <E> List<T> getBy(String sortProperty, E sortValue);

    /**
     *
     * @param <E> type de sort value
     * @param sortProperty type de sort value
     * @param sortValue type de sort value
     * @return un Ã©lÃ©ment de T éléments triés par sortProperty = sortValue
     */
    <E> T getOneBy(String sortProperty, E sortValue);

    /**
     *
     * @param <E> type de sort value
     * @param <F> type de sort value
     * @param sortProperty premier condition
     * @param andSortProperty seconde condition
     * @param sortValue triÃ© par cette valeur
     * @param andSortValue type de sort value
     * @return une liste de T éléments triés par sortProperty = sortValue et
     * andSortProperty
     */
    <E, F> List<T> getBy(String sortProperty, String andSortProperty, E sortValue, F andSortValue);

    /**
     *
     * @param <E> type de sort value
     * @param sortProperty type de sort value
     * @param sortValue type de sort value
     * @return une liste de T éléments triés par sortProperty pour sortValue
     */
    public <E> List<T> getNonBy(String sortProperty, E sortValue);

    /**
     *
     * @param <E> type de sort value
     * @param sortProperty type de sort value
     * @param sortValue type de sort value
     * @param sortAsc type de sort value
     * @return une liste de T éléments triés par sortProperty like sortValue
     */
    <E> List<T> getAll(String sortProperty, E sortValue, boolean sortAsc);

    List<T> getAll(int first, int count, String sortProperty, boolean sortAsc);

    T saveOne(final T t);

    T updateOne(final T t);

    boolean deleteOne(final PK id);

    boolean deleteOne(final T t);

    void deleteAll();

    List<T> executeQuery(Query query);

    int executeUpdate(Query query);

    EntityManager getEntityManager();

    public boolean deleteRealOne(PK id);

    boolean deleteRealOne(final T t);

    public T find(PK id);

    /*Partie 2 TestWork une autre manière 
     *Persist, delete, update, View
     */
    
    public List<T> getOrderDesc(String attribut);

    /**
     * Permet de sélectionner une entité en prenant en paramètre son Identifiant
     *
     * @param attribut
     * @param order
     * @return T
     */
    public List<T> getAll(String attribut, String order);

    public T selectionner(PK k);

    T selectionner(String propriete, Object valeur);

    /**
     * Permet de persister une entité
     *
     * @param valeur
     * @param attribut
     * @return
     */
    public List<T> selectionnerParTableAttribut(Object valeur, String attribut);

    public List<T> selectionnerParDeuxAttributs(String att1, String att2, Object val1, Object val2);

    public List<T> selectionner(String att1, String att2, String att3, Object val1, Object val2);

    public List<T> selectionnerParCleEtrangere(Object valeur, String attribut);

    public List<T> selectionnerInterventionPeriode(Date date1, Date date2);

    public void ajouter(T t);

    public void ajouter(List<T> list);

    /**
     * Permet de modifier une entité en prenant en paramètre une autre du même
     * identifiant
     *
     * @param t
     * @return
     */
    public T modifier(final T t);

    /**
     * Permet de modifier une liste d'entités
     *
     * @param list
     */
    public List<T> modifier(List<T> list);

    public List<T> modifierListe(List<T> list);

    /**
     * Retourne la liste de toutes les entités
     *
     * @return
     */
    public List<T> selectionnerTout();

    /**
     * Retourne la liste de toutes les entités commençants par un mot
     *
     * @param propriete
     * @param mot
     * @return
     */
    public List<T> selectionnerTout(String propriete, String mot);

    /**
     * Supprime logiquement une entité
     *
     * @param t
     */
    public void supprimerLogique(T t);

    /**
     * Supprime logiquement une entité
     *
     * @param t
     */
    public void supprimer(T t);

    /**
     * Supprime logiquement une entité à partir de son identifiant
     *
     * @param k
     */
    public void supprimer(PK k);

    public void supprimer(T t, PK k);  // à enlever

    //Nbre d'enregistrement
    public int compter(); // changer le type de retour en Long

    /**
     * Supprime tous les objets d'une classe entité
     */
    public void supprimerTout();

    /*
     * Vérifier l'existance d'une valeur
     */
    public boolean exists(String value, String attribut);

    /**
     * Vérifier l'existence avancée
     *
     * @param attribut1
     * @param attribut2
     * @param value1
     * @param value2
     * @return
     *
     */
    public boolean exists(String attribut1, String attribut2, Object value1, Object value2);

    /**
     * Vérifier l'existence d'une valeur en fonction de l'entité
     *
     * @param attribut1
     * @param attribut2
     * @param value1
     * @param value2
     * @return
     */
    public boolean existEntite(String attribut1, String attribut2, String value1, String value2);

    public String getExecutedSql();

    public String getDatabaseName();

    public List<Object[]> executerProcedure(String nomProcedure, Map<String, Object> parametres);

}
