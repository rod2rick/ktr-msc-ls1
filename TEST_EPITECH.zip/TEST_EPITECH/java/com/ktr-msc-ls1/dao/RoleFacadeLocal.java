/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ktr-msc-ls1.dao;

import com.ktr-msc-ls1.Entities.Role;
import java.util.List;
import javax.ejb.Local;
import com.ktr-msc-ls1.dao.core.AppliDaoBeanLocal;

/**
 *
 * @author ROT2RICK
 */
@Local
public interface RoleFacadeLocal extends AppliDaoBeanLocal<Role, Long> {

  
}
